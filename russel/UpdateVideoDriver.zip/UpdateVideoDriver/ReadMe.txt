WARNING!WARNING!
This is NOT a real driver update.
This is just to download a keylogger onto a device. 
PLEASE DO NOT RUN ANY OF THIS UNLESS YOU UNDERSTAND THE RISKS
WARNING!WARNING!